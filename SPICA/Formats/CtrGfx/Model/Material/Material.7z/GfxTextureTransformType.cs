﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    enum GfxTextureTransformType : uint
    {
        DccMaya,
        DccSoftImage,
        Dcc3dsMax
    }
}
