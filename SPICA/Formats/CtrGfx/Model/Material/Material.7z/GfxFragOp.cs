﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    struct GfxFragOp
    {
        public GfxFragOpDepth   Depth;
        public GfxFragOpBlend   Blend;
        public GfxFragOpStencil Stencil;
    }
}
