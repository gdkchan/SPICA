﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    enum GfxTranslucencyKind : uint
    {
        Layer0,
        Opaque,
        Layer1,
        Transparent,
        Layer2,
        Subtractive,
        Additive,
        Layer3
    }
}
