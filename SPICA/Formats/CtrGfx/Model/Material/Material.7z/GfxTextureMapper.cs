﻿using SPICA.Serialization.Attributes;

namespace SPICA.Formats.CtrGfx.Model.Material
{
    class GfxTextureMapper
    {
        private uint Unk;

        private uint DynamicAllocPtr;
        private uint TexturePtr; //TODO set ref

        public readonly GfxTextureSampler Sampler;

        [Inline, FixedLength(14)] private uint[] Commands;
    }
}
