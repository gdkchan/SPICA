﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    class GfxProcTextureMapper
    {
        //TODO
    }
}
