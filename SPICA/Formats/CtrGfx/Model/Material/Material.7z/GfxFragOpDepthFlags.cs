﻿using System;

namespace SPICA.Formats.CtrGfx.Model.Material
{
    [Flags]
    enum GfxFragOpDepthFlags
    {
        IsTestEnabled = 1 << 0,
        IsMaskEnabled = 1 << 1
    }
}
