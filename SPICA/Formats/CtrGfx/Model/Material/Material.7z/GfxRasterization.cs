﻿using SPICA.PICA.Commands;
using SPICA.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace SPICA.Formats.CtrGfx.Model.Material
{
    struct GfxRasterization
    {
        public bool IsPolygonOffsetEnabled;

        public PICAFaceCulling FaceCulling;

        public float PolygonOffsetUnit;

        [FixedLength(2)] private uint[] FaceCullingCommand;
    }
}
