﻿using System.Numerics;

namespace SPICA.Formats.CtrGfx.Model.Material
{
    class GfxFragmentShader
    {
        public Vector4 TexEnvBufferColor;

        public GfxFragmentLighting FragmentLighting;


    }
}
