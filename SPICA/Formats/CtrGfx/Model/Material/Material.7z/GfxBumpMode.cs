﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    enum GfxBumpMode : uint
    {
        NotUsed,
        AsBump,
        AsTangent
    }
}
