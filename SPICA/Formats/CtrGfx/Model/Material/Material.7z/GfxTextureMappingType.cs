﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    enum GfxTextureMappingType : uint
    {
        UvCoordinateMap,
        CameraCubeEnvMap,
        CameraSphereEnvMap,
        ProjectionMap,
        Shadow,
        ShadowBox
    }
}
