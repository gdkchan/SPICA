﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    enum GfxFragOpBlendMode
    {
        None,
        Blend,
        BlendSeparate,
        LogicalOp
    }
}
