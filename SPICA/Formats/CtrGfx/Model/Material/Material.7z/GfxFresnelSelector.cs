﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    enum GfxFresnelSelector : uint
    {
        No,
        Pri,
        Sec,
        PriSec
    }
}
