﻿using System.Numerics;

namespace SPICA.Formats.CtrGfx.Model.Material
{
    class GfxTextureSampler
    {
        public Vector4 BorderColor;

        public float MinLOD;
    }
}
