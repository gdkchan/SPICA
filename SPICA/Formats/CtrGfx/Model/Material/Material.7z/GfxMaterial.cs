﻿using SPICA.Formats.Common;
using SPICA.Serialization.Attributes;

namespace SPICA.Formats.CtrGfx.Model.Material
{
    class GfxMaterial : INamed
    {
        private GfxVersion Version;

        public GfxMaterialFlags Flags;

        public GfxTexCoordConfig   TexCoordConfig;
        public GfxTranslucencyKind TranslucencyKind;

        public GfxMaterialColor Colors;

        public GfxFragOp FragmentOperation;

        public int UsedTextureCoordsCount;

        [Inline, FixedLength(3)] public readonly GfxTextureCoord[] TextureCoords;

        [Inline, FixedLength(3)] public readonly GfxTextureMapper[] TextureMappers;

        public readonly GfxProcTextureMapper ProceduralTextureMapper;

        private uint ShaderPtr; //TODO use Shader when it's implemented

        private string _Name;

        public string Name
        {
            get
            {
                return _Name;
            }
            set
            {
                _Name = value ?? throw Exceptions.GetNullException("Name");
            }
        }
    }
}
