﻿using System;

namespace SPICA.Serialization.Attributes
{
    [AttributeUsage(AttributeTargets.Field)]
    class RangeAttribute : Attribute { }
}
