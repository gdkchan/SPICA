﻿namespace SPICA.Formats.GFL2.Model.Material
{
    public enum GFMinFilter : uint
    {
        NearestMipmapNearest = 1,
        NearestMipmapLinear = 2,
        LinearMipmapNearest = 4,
        LinearMipmapLinear = 5
    }
}
