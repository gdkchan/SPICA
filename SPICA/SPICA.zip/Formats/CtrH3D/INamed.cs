﻿namespace SPICA.Formats.CtrH3D
{
    public interface INamed
    {
        string Name { get; set; }
    }
}
