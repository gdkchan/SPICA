﻿namespace SPICA.Formats.CtrH3D.Model.Mesh
{
    public enum H3DSubMeshSkinning : byte
    {
        None,
        Smooth,
        Rigid
    }
}
