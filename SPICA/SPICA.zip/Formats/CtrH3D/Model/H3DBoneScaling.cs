﻿namespace SPICA.Formats.CtrH3D.Model
{
    public enum H3DBoneScaling : byte
    {
        Standard,
        Maya,
        SoftImage
    }
}
