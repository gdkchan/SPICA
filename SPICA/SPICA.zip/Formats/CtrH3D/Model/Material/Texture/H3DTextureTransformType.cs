﻿namespace SPICA.Formats.CtrH3D.Model.Material.Texture
{
    public enum H3DTextureTransformType : byte
    {
        DccMaya,
        DccSoftImage,
        Dcc3dsMax
    }
}
