﻿namespace SPICA.Formats.CtrH3D.Model.Material.Texture
{
    public enum H3DTextureMagFilter : byte
    {
        Nearest,
        Linear
    }
}
