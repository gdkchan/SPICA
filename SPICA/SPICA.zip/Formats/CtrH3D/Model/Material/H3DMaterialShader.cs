﻿namespace SPICA.Formats.CtrH3D.Model.Material
{
    public class H3DMaterialShader
    {
        //TODO
    }
}
