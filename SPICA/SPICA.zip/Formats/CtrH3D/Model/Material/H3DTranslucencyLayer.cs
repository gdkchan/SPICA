﻿namespace SPICA.Formats.CtrH3D.Model.Material
{
    public enum H3DTranslucencyLayer
    {
        Layer0,
        Layer1,
        Layer2,
        Layer3
    }
}
