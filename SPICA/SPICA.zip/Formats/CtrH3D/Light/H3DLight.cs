﻿namespace SPICA.Formats.CtrH3D.Light
{
    public class H3DLight : INamed
    {
        //TODO
        public string Name { get { return null; } set { } }
    }
}
