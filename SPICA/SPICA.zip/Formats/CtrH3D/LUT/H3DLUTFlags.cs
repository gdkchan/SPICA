﻿using System;

namespace SPICA.Formats.CtrH3D.LUT
{
    [Flags]
    public enum H3DLUTFlags : byte
    {
        IsAbsolute = 1 << 0
    }
}
