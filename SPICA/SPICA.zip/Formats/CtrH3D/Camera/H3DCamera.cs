﻿namespace SPICA.Formats.CtrH3D.Camera
{
    public class H3DCamera : INamed
    {
        //TODO
        public string Name { get { return null; } set { } }
    }
}
