﻿namespace SPICA.Formats.CtrH3D.Shader
{
    public class H3DShader : INamed
    {
        //TODO
        public string Name { get { return null; } set { } }
    }
}
