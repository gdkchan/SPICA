﻿namespace SPICA.Formats.CtrH3D
{
    public class H3DVertexDataAttribute
    {
        //TODO
    }
}
