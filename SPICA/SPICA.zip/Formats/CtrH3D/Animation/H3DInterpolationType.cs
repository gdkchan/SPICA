﻿namespace SPICA.Formats.CtrH3D.Animation
{
    public enum H3DInterpolationType : byte
    {
        Step,
        Linear,
        Hermite
    }
}
