﻿namespace SPICA.Formats.CtrH3D.Animation
{
    public enum H3DAnimationFlags : uint
    {
        IsLooping = 1 << 0
    }
}
