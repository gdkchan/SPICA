﻿using SPICA.Serialization;
using SPICA.Serialization.Attributes;

using System;

namespace SPICA.Formats.CtrH3D.Animation
{
    public class H3DAnimationElement : ICustomSerialization
    {
        public string Name;

        public H3DAnimTargetType TargetType;
        public H3DAnimPrimitiveType PrimitiveType;

        [Ignore] public object Content;

        void ICustomSerialization.Deserialize(BinaryDeserializer Deserializer)
        {
            switch (PrimitiveType)
            {
                case H3DAnimPrimitiveType.Vector2D:      Content = Deserializer.Deserialize<H3DAnimVector2D>();      break;
                case H3DAnimPrimitiveType.Transform:     Content = Deserializer.Deserialize<H3DAnimTransform>();     break;
                case H3DAnimPrimitiveType.QuatTransform: Content = Deserializer.Deserialize<H3DAnimQuatTransform>(); break;
                case H3DAnimPrimitiveType.Boolean:       Content = Deserializer.Deserialize<H3DAnimBoolean>();       break;
                case H3DAnimPrimitiveType.MtxTransform:  Content = Deserializer.Deserialize<H3DAnimMtxTransform>();  break;
            }
        }

        bool ICustomSerialization.Serialize(BinarySerializer Serializer)
        {
            throw new NotImplementedException();
        }
    }
}
