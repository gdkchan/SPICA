﻿namespace SPICA.Formats.CtrH3D.Scene
{
    public class H3DScene : INamed
    {
        //TODO
        public string Name { get { return null; } set { } }
    }
}
