﻿namespace SPICA.Formats.CtrH3D
{
    public struct PatriciaTreeNode
    {
        public uint ReferenceBit;
        public ushort LeftNodeIndex;
        public ushort RightNodeIndex;
        public string Name;
    }
}
