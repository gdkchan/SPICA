﻿using SPICA.Math3D;

namespace SPICA.Formats.Generic.StudioMdl
{
    struct SMDBone
    {
        public int NodeIndex;

        public Vector3D Translation;
        public Vector3D Rotation;
    }
}
