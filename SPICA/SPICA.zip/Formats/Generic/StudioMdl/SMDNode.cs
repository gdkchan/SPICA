﻿namespace SPICA.Formats.Generic.StudioMdl
{
    struct SMDNode
    {
        public int Index;

        public string Name;

        public int ParentIndex;
    }
}
