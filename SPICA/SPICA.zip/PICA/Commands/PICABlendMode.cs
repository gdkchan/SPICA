﻿namespace SPICA.PICA.Commands
{
    public enum PICABlendMode
    {
        LogicalOp,
        Blend
    }
}
