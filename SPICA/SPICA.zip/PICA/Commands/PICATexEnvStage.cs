﻿namespace SPICA.PICA.Commands
{
    public class PICATexEnvStage
    {
        public PICATexEnvSource Source;
        public PICATexEnvOperand Operand;
        public PICATexEnvCombiner Combiner;
        public PICATexEnvColor Color;
        public PICATexEnvScale Scale;

        public bool UpdateRGBBuffer;
        public bool UpdateAlphaBuffer;

        public PICATexEnvStage()
        {
            Source = new PICATexEnvSource();
            Operand = new PICATexEnvOperand();
            Combiner = new PICATexEnvCombiner();
            Color = new PICATexEnvColor();
            Scale = new PICATexEnvScale();
        }
    }
}
