﻿namespace SPICA.PICA.Commands
{
    public struct PICAFixedAttribute
    {
        public PICAAttributeName Name;
        public PICAVectorFloat24 Value;
    }
}
