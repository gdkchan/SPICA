﻿namespace SPICA.PICA.Commands
{
    public enum PICAFragOpMode
    {
        Default = 0,
        Gas = 1,
        Shadow = 3
    }
}
