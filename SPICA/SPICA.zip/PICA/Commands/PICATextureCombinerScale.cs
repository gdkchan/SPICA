﻿namespace SPICA.PICA.Commands
{
    public enum PICATextureCombinerScale
    {
        One,
        Two,
        Four
    }
}
