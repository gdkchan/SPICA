﻿namespace SPICA.PICA.Commands
{
    public enum PICALUTInput
    {
        CosNormalHalf,
        CosViewHalf,
        CosNormalView,
        CosLightNormal,
        CosLightSpot,
        CosPhi
    }
}
