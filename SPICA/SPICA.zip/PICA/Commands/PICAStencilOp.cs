﻿namespace SPICA.PICA.Commands
{
    public enum PICAStencilOp
    {
        Keep,
        Zero,
        Replace,
        Increment,
        Decrement,
        Invert,
        IncrementWrap,
        DecrementWrap
    }
}
