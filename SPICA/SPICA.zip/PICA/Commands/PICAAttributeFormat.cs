﻿namespace SPICA.PICA.Commands
{
    public enum PICAAttributeFormat
    {
        Byte,
        Ubyte,
        Short,
        Float
    }
}
