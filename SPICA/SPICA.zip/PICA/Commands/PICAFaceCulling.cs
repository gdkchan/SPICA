﻿namespace SPICA.PICA.Commands
{
    public enum PICAFaceCulling
    {
        Never,
        FrontFace,
        BackFace
    }
}
