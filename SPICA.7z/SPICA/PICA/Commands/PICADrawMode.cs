﻿namespace SPICA.PICA.Commands
{
    public enum PICADrawMode : byte
    {
        TriangleStrip,
        TriangleFan,
        Triangles,
        GeoPrimitive
    }
}
