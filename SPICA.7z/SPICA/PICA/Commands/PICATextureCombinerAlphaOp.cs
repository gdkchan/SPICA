﻿namespace SPICA.PICA.Commands
{
    public enum PICATextureCombinerAlphaOp
    {
        Alpha,
        OneMinusAlpha,
        Red,
        OneMinusRed,
        Green,
        OneMinusGreen,
        Blue,
        OneMinusBlue
    }
}
