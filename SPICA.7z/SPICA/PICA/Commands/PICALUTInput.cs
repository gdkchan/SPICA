﻿namespace SPICA.PICA.Commands
{
    public enum PICALUTInput : uint
    {
        CosNormalHalf,
        CosViewHalf,
        CosNormalView,
        CosLightNormal,
        CosLightSpot,
        CosPhi
    }
}
