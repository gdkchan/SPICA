﻿namespace SPICA.PICA.Commands
{
    public enum PICAFaceCulling : uint
    {
        Never,
        FrontFace,
        BackFace
    }
}
