﻿namespace SPICA.PICA.Commands
{
    public enum PICATextureFilter : uint
    {
        Nearest,
        Linear
    }
}
