﻿namespace SPICA.PICA.Commands
{
    public enum PICAPrimitiveMode : uint
    {
        Triangles,
        TriangleStrip,
        TriangleFan,
        GeometryPrimitive
    }
}
