﻿namespace SPICA.PICA.Commands
{
    public enum PICAAttributeFormat : uint
    {
        Byte,
        Ubyte,
        Short,
        Float
    }
}
