﻿namespace SPICA.PICA.Commands
{
    public enum PICATestFunc
    {
        Never,
        Always,
        Equal,
        Notequal,
        Less,
        Lequal,
        Greater,
        Gequal
    }
}
