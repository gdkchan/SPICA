﻿namespace SPICA.PICA.Commands
{
    public enum PICABlendEquation
    {
        FuncAdd,
        FuncSubtract,
        FuncReverseSubtract,
        Min,
        Max
    }
}
