﻿namespace SPICA.PICA.Commands
{
    public enum PICATextureWrap : uint
    {
        ClampToEdge,
        ClampToBorder,
        Repeat,
        Mirror
    }
}
