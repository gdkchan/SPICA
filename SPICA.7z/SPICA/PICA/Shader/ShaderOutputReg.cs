﻿namespace SPICA.PICA.Shader
{
    public struct ShaderOutputReg
    {
        public ShaderOutputRegName Name;

        public uint Mask;
    }
}
