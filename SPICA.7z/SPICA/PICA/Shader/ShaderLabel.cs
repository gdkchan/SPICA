﻿namespace SPICA.PICA.Shader
{
    public struct ShaderLabel
    {
        public uint Id;
        public uint Offset;
        public uint Length;

        public string Name;
    }
}
