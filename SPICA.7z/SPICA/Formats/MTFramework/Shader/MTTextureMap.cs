﻿using System.IO;

namespace SPICA.Formats.MTFramework.Shader
{
    public class MTTextureMap : MTShaderEffect
    {
        public MTTextureMap(BinaryReader Reader)
        {
            //TODO
        }
    }
}
