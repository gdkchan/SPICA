﻿namespace SPICA.Formats.MTFramework.Shader
{
    public class MTShaderEffect
    {
        public string Name { get; set; }
        public string Type { get; set; }
    }
}
