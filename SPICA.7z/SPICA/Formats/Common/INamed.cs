﻿namespace SPICA.Formats.Common
{
    public interface INamed
    {
        string Name { get; set; }
    }
}
