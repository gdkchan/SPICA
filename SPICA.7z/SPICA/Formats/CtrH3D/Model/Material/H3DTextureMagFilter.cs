﻿namespace SPICA.Formats.CtrH3D.Model.Material
{
    public enum H3DTextureMagFilter : byte
    {
        Nearest,
        Linear
    }
}
