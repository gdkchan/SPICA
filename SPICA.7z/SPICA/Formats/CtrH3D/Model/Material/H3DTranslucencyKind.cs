﻿namespace SPICA.Formats.CtrH3D.Model.Material
{
    public enum H3DTranslucencyKind
    {
        LayerConfig0,
        LayerConfig1,
        LayerConfig2,
        LayerConfig3,
        LayerConfig4,
        LayerConfig5,
        LayerConfig6,
        LayerConfig7
    }
}
