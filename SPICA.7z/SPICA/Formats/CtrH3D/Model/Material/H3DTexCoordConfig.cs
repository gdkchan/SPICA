﻿namespace SPICA.Formats.CtrH3D.Model.Material
{
    public enum H3DTexCoordConfig
    {
        Config0120,
        Config0110,
        Config0111,
        Config0112,
        Config0121,
        Config0122
    }
}
