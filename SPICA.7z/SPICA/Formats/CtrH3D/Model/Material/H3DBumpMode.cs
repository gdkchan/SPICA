﻿namespace SPICA.Formats.CtrH3D.Model.Material
{
    public enum H3DBumpMode : byte
    {
        NotUsed,
        AsBump,
        AsTangent
    }
}
