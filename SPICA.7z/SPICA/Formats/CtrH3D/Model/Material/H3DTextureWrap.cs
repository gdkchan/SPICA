﻿namespace SPICA.Formats.CtrH3D.Model.Material
{
    public enum H3DTextureWrap : byte
    {
        ClampToEdge,
        ClampToBorder,
        Repeat,
        Mirror
    }
}
