﻿namespace SPICA.Formats.CtrH3D.Model.Mesh
{
    public struct H3DSubMeshCulling
    {
        //TODO
    }
}
