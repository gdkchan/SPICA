﻿namespace SPICA.Formats.CtrH3D.Model.Mesh
{
    public enum H3DMeshType : byte
    {
        Normal,
        Silhouette
    }
}
