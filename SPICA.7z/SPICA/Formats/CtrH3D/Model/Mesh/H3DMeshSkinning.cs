﻿namespace SPICA.Formats.CtrH3D.Model.Mesh
{
    public enum H3DMeshSkinning : byte
    {
        Mixed,
        Rigid,
        Smooth
    }
}
