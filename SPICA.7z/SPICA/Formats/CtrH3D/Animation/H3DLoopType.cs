﻿namespace SPICA.Formats.CtrH3D.Animation
{
    public enum H3DLoopType : byte
    {
        None,
        Repeat,
        MirroredRepeat,
        RelativeRepeat
    }
}
