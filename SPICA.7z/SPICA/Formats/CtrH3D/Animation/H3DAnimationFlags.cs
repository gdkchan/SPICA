﻿namespace SPICA.Formats.CtrH3D.Animation
{
    public enum H3DAnimationFlags : byte
    {
        IsLooping  = 1 << 0,
        IsConstant = 1 << 1
    }
}
