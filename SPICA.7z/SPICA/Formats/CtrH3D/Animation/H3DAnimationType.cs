﻿namespace SPICA.Formats.CtrH3D.Animation
{
    public enum H3DAnimationType : byte
    {
        Skeletal,
        Material,
        Visibility,
        Light,
        Camera,
        Fog
    }
}
