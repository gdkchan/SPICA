﻿using SPICA.Formats.Common;

namespace SPICA.Formats.CtrH3D.Fog
{
    public class H3DFog : INamed
    {
        //TODO
        public string Name { get { return null; } set { } }
    }
}
