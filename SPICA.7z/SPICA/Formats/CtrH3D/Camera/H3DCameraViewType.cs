﻿namespace SPICA.Formats.CtrH3D.Camera
{
    public enum H3DCameraViewType : byte
    {
        Aim,
        LookAt,
        Rotate
    }
}
