﻿namespace SPICA.Formats.CtrH3D.Camera
{
    public class H3DCameraProjectionOrthogonal
    {
        public float ZNear;
        public float ZFar;
        public float AspectRatio;
        public float Height;
    }
}
