﻿namespace SPICA.Formats.CtrH3D.Camera
{
    public class H3DCameraProjectionPerspective
    {
        public float ZNear;
        public float ZFar;
        public float AspectRatio;
        public float FOVY;
    }
}
