﻿namespace SPICA.Formats.CtrH3D.Camera
{
    public enum H3DCameraProjectionType : byte
    {
        Perspective,
        Orthogonal
    }
}
