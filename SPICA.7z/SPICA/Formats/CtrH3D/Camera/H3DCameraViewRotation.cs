﻿using System.Numerics;

namespace SPICA.Formats.CtrH3D.Camera
{
    public class H3DCameraViewRotation
    {
        public Vector3 Rotation;
    }
}
