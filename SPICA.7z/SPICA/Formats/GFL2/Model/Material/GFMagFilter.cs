﻿namespace SPICA.Formats.GFL2.Model.Material
{
    public enum GFMagFilter : uint
    {
        Nearest,
        Linear
    }
}
