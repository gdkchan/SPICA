﻿namespace SPICA.Formats.GFL2.Model.Material
{
    public enum GFTextureWrap : uint
    {
        ClampToEdge,
        ClampToBorder,
        Repeat,
        Mirror
    }
}
