﻿namespace SPICA.Formats.CtrGfx.Animation
{
    public enum GfxLoopMode : uint
    {
        OneTime,
        Loop
    }
}
