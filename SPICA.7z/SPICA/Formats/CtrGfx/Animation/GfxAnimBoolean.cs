﻿using System.Collections.Generic;

namespace SPICA.Formats.CtrGfx.Animation
{
    public class GfxAnimBoolean
    {
        public readonly List<bool> Values;

        public GfxAnimBoolean()
        {
            Values = new List<bool>();
        }
    }
}
