﻿namespace SPICA.Formats.CtrGfx.Animation
{
    public enum GfxLoopType : byte
    {
        None,
        Repeat,
        MirroredRepeat,
        RelativeRepeat
    }
}
