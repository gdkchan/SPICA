﻿using SPICA.Formats.Common;

using System;

namespace SPICA.Formats.CtrGfx.Shader
{
    public class GfxShader : INamed
    {
        public string Name
        {
            get => throw new NotImplementedException();
            set => throw new NotImplementedException();
        }
    }
}
