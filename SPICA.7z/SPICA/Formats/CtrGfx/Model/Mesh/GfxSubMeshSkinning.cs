﻿namespace SPICA.Formats.CtrGfx.Model.Mesh
{
    public enum GfxSubMeshSkinning : uint
    {
        None,
        Rigid,
        Smooth
    }
}
