﻿namespace SPICA.Formats.CtrGfx.Model.Mesh
{
    public enum GfxVertexBufferType : uint
    {
        None,
        Fixed,
        Interleaved
    }
}
