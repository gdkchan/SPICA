﻿namespace SPICA.Formats.CtrGfx.Model
{
    public enum GfxModelFlags : uint
    {
        IsVisible            = 1 << 0,
        IsNonUniformScalable = 1 << 1
    }
}
