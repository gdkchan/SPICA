﻿namespace SPICA.Formats.CtrGfx.Model
{
    class GfxModelSkeletal : GfxModel
    {
        public GfxSkeleton Skeleton;
    }
}
