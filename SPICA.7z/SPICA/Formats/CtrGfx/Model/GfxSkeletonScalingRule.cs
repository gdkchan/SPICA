﻿namespace SPICA.Formats.CtrGfx.Model
{
    public enum GfxSkeletonScalingRule : uint
    {
        Standard,
        Maya,
        SoftImage
    }
}
