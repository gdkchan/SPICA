﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    public enum GfxFresnelSelector : uint
    {
        No,
        Pri,
        Sec,
        PriSec
    }
}
