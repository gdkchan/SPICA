﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    public class GfxShaderDesc
    {
        //TODO
    }
}
