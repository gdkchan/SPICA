﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    public enum GfxTexCoordConfig : uint
    {
        Config0120,
        Config0110,
        Config0111,
        Config0112,
        Config0121,
        Config0122
    }
}
