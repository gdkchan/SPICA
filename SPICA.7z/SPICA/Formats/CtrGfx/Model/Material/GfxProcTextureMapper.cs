﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    public class GfxProcTextureMapper
    {
        //TODO
    }
}
