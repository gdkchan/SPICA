﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    public class GfxShaderParam
    {
        //TODO
    }
}
