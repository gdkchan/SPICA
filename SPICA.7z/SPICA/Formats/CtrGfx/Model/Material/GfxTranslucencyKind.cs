﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    public enum GfxTranslucencyKind : uint
    {
        Layer0,
        Layer1,
        Layer2,
        Layer3
    }
}
