﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    public enum GfxTexEnvConstant : uint
    {
        Constant0,
        Constant1,
        Constant2,
        Constant3,
        Constant4,
        Constant5,
        Emission,
        Ambient,
        Diffuse,
        Specular0,
        Specular1
    }
}
