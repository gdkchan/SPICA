﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    public enum GfxFragOpBlendMode : uint
    {
        None,
        Blend,
        BlendSeparate,
        LogicalOp
    }
}
