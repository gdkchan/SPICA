﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    public enum GfxTextureTransformType : uint
    {
        DccMaya,
        DccSoftImage,
        Dcc3dsMax
    }
}
