﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    public enum GfxBumpMode : uint
    {
        NotUsed,
        AsBump,
        AsTangent
    }
}
