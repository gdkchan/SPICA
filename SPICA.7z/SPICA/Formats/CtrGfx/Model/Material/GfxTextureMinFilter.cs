﻿namespace SPICA.Formats.CtrGfx.Model.Material
{
    public enum GfxTextureMinFilter
    {
        Nearest,
        Linear,
        NearestMipmapNearest,
        NearestMipmapLinear,
        LinearMipmapNearest,
        LinearMipmapLinear
    }
}
