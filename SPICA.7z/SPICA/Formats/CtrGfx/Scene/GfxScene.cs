﻿using SPICA.Formats.Common;

using System;

namespace SPICA.Formats.CtrGfx.Scene
{
    public class GfxScene : INamed
    {
        public string Name
        {
            get => throw new NotImplementedException();
            set => throw new NotImplementedException();
        }
    }
}
