﻿using SPICA.Formats.Common;

using System;

namespace SPICA.Formats.CtrGfx.Light
{
    public class GfxLight : INamed
    {
        public string Name
        {
            get => throw new NotImplementedException();
            set => throw new NotImplementedException();
        }
    }
}
