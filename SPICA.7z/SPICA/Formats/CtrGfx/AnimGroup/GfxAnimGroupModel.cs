﻿namespace SPICA.Formats.CtrGfx.AnimGroup
{
    class GfxAnimGroupModel : GfxAnimGroupElement
    {
        private GfxAnimGroupObjType ObjType2;

        public GfxAnimGroupModel()
        {
            ObjType = ObjType2 = GfxAnimGroupObjType.Model;
        }
    }
}
