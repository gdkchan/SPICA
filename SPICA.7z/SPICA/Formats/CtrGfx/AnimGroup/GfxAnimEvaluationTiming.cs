﻿namespace SPICA.Formats.CtrGfx.AnimGroup
{
    public enum GfxAnimEvaluationTiming
    {
        BeforeWorldUpdate,
        AfterSceneCull
    }
}
