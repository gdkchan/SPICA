﻿namespace SPICA.Formats.CtrGfx
{
    public struct GfxRevHeader
    {
        public uint MagicNumber;
        public uint Revision;
    }
}
