﻿namespace SPICA.Formats.CtrGfx
{
    public enum GfxStringFormat : uint
    {
        Ascii,
        Utf8,
        Utf16LE,
        Utf16BE
    }
}
