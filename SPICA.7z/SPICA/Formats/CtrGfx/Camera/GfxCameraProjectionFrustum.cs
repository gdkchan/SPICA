﻿namespace SPICA.Formats.CtrGfx.Camera
{
    public class GfxCameraProjectionFrustum : GfxCameraProjectionOrthogonal { }
}
