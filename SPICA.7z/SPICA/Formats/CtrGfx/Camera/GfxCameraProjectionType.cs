﻿namespace SPICA.Formats.CtrGfx.Camera
{
    public enum GfxCameraProjectionType : uint
    {
        Perspective,
        Frustum,
        Orthogonal
    }
}
