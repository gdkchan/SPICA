﻿using System.Numerics;

namespace SPICA.Formats.CtrGfx.Camera
{
    class GfxCameraViewRotation : GfxCameraView
    {
        public bool IsInheritingRotation;

        public Vector3 Rotation;
    }
}
