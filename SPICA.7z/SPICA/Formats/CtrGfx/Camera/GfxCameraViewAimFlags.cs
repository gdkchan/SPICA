﻿namespace SPICA.Formats.CtrGfx.Camera
{
    public enum GfxCameraViewAimFlags
    {
        IsInheritingTargetRotation    = 1 << 0,
        IsInheritingTargetTranslation = 1 << 1
    }
}
