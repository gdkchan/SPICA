﻿namespace SPICA.Formats.CtrGfx.Camera
{
    public enum GfxCameraViewType : uint
    {
        Aim,
        LookAt,
        Rotate
    }
}
