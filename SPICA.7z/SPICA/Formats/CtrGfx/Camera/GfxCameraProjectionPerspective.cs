﻿namespace SPICA.Formats.CtrGfx.Camera
{
    public class GfxCameraProjectionPerspective : GfxCameraProjection
    {
        public float AspectRatio;
        public float FOVY;
    }
}
