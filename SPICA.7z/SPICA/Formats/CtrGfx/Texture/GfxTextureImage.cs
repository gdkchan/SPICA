﻿namespace SPICA.Formats.CtrGfx.Texture
{
    class GfxTextureImage : GfxTexture
    {
        public GfxTextureImageData Image;
    }
}
