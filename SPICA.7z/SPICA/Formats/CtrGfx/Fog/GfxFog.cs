﻿using SPICA.Formats.Common;

using System;

namespace SPICA.Formats.CtrGfx.Fog
{
    public class GfxFog : INamed
    {
        public string Name
        {
            get => throw new NotImplementedException();
            set => throw new NotImplementedException();
        }
    }
}
