﻿namespace SPICA.Formats.CtrGfx
{
    public enum GfxMetaDataType : uint
    {
        Single,
        Integer,
        String,
        Vector3,
        Color
    }
}
