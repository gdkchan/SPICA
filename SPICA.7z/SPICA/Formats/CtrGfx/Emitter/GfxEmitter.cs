﻿using SPICA.Formats.Common;

using System;

namespace SPICA.Formats.CtrGfx.Emitter
{
    public class GfxEmitter : INamed
    {
        public string Name
        {
            get => throw new NotImplementedException();
            set => throw new NotImplementedException();
        }
    }
}
