﻿namespace SPICA.Serialization
{
    enum CmpOp
    {
        Equal,
        Notqual,
        Greater,
        Gequal,
        Less,
        Lequal
    }
}
