﻿using System;

namespace SPICA.Serialization.Attributes
{
    class IgnoreAttribute : Attribute { }
}
