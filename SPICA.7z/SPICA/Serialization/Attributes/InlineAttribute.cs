﻿using System;

namespace SPICA.Serialization.Attributes
{
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Class)]
    class InlineAttribute : Attribute { }
}
