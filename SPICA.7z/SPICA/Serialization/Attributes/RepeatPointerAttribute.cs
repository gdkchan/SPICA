﻿using System;

namespace SPICA.Serialization.Attributes
{
    [AttributeUsage(AttributeTargets.Field)]
    class RepeatPointerAttribute : Attribute { }
}
