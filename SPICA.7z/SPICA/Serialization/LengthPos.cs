﻿namespace SPICA.Serialization
{
    enum LengthPos
    {
        BeforePtr,
        AfterPtr
    }
}
