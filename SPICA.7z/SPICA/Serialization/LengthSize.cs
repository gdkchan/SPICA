﻿namespace SPICA.Serialization
{
    enum LengthSize
    {
        Short,
        Integer
    }
}
