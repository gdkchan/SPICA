﻿namespace SPICA.Serialization
{
    enum PointerType
    {
        Absolute,
        SelfRelative
    }
}
