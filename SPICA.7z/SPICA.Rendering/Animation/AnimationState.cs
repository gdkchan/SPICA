﻿namespace SPICA.Rendering.Animation
{
    public enum AnimationState
    {
        Stopped,
        Paused,
        Playing
    }
}
