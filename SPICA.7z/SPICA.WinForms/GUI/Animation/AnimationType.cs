﻿namespace SPICA.WinForms.GUI.Animation
{
    enum AnimationType
    {
        Skeletal,
        Material,
        Visibility,
        Light,
        Camera,
        Fog
    }
}
